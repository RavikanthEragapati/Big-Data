package CSV;

import java.io.IOException;
import java.io.StringReader;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.opencsv.CSVReader;

import java.util.regex.*;

public class CSVMapper extends MapReduceBase
implements Mapper<LongWritable, Text, Text, Text> {

private Text Campaign = new Text();
private Text Zip = new Text();
private Text dollar = new Text();

public void map(LongWritable key, Text value,
                OutputCollector<Text, Text> output,
                Reporter reporter) throws IOException {
  String line = value.toString();
  CSVReader R = new CSVReader(new StringReader(line));
  String[] ParsedLine = R.readNext();
  R.close();
  /* todo
   * Check for null and number of columns
   */
  if(ParsedLine[6].length()== 5)
  {
  Campaign.set(ParsedLine[0]);
  Zip.set(ParsedLine[6]);
  if(ParsedLine.length>10){
  dollar.set(ParsedLine[11].replaceAll("[^0-9]", ""));
  }
  
  }
  else{
	  //ignored
  }
  output.collect(Campaign, new Text(Zip+":"+dollar));
  
  
 }
}