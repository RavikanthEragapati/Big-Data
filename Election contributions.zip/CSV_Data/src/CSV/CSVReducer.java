package CSV;

import java.io.IOException;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import mrtools.CountMap;
import mrtools.NBest;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

public class CSVReducer extends MapReduceBase
implements Reducer<Text, Text, Text, Text> {
	    NBest<Text> Best = new NBest<Text>(3);
        CountMap<Text> Counts= new CountMap<Text>();
        public void reduce(Text key, Iterator<Text> values,
                        OutputCollector<Text, Text> output,
                        Reporter reporter) throws IOException {
        		//First, reset the counter and count all values for this key into it
                Counts.clear();
                
               
                while(values.hasNext())
                  {
                      String DollarZip=values.next().toString();
                      String[] DollarZipArray=DollarZip.split(":");
                      if(DollarZipArray.length == 2)
                      {
                          int Dollar = Integer.parseInt(DollarZipArray[1]);
                          Counts.put(new Text(DollarZipArray[0]), Dollar);
                      }
                      else
                      {
                          reporter.incrCounter("Bad Input","No dollar is reduced",1);
                      }
                  }

                /*
                int highest = -1;
                int totalSupport = 0;
                for(Map.Entry<Text, Integer> ME : Counts.entrySet()){
                	totalSupport = totalSupport+ME.getValue();
                	highest=Math.max(highest, ME.getValue());
                }
                output.collect(key, new Text(Integer.toString(highest)+":"+
                Integer.toString(totalSupport-highest)));
                */
                
                
                //Counts.countStringsInto(values);
                //Now put the counter into the NBest sorter set to keep 3 best for each key
                Best.clear();
                Best.putMap(Counts);
                output.collect(key,new Text(Best.bestEntryCountTSV(",")));
            
        }
}
